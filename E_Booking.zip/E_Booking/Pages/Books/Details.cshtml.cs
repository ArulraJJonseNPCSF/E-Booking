﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using E_Booking.Data;
using E_Booking.Models;
using Microsoft.AspNetCore.Authorization;

namespace E_Booking.Pages.Books
{
    //[Authorize(Roles = "Admin, Users")]
    public class DetailsModel : PageModel
    {
        private readonly E_Booking.Data.E_BookingContext _context;

        public DetailsModel(E_Booking.Data.E_BookingContext context)
        {
            _context = context;
        }

        public Book Book { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Book = await _context.Book.FirstOrDefaultAsync(m => m.ID == id);

            if (Book == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
