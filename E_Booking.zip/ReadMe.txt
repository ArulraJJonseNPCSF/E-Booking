E_Booking is the code for the WebApplication
DB Directory is the database for the WebApplication